// Muat .env sederhana (tanpa dependency tambahan) sebelum membaca process.env.
try {
  require('fs').readFileSync(require('path').join(__dirname, '.env'), 'utf8').split(/\r?\n/).forEach(line => {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  });
} catch { /* .env opsional */ }

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const cookieParser = require('cookie-parser');
const { Server } = require('socket.io');
const shortsLib = require('./lib/shorts');

const app = express();
app.set('trust proxy', 1);
const server = http.createServer(app);
// Heartbeat pendek: aman untuk mode long-polling lewat proxy (mis. Vercel rewrites).
const io = new Server(server, { pingInterval: 10000, pingTimeout: 20000 });
const PORT = process.env.PORT || 2255;
const PUBLIC_DIR = path.join(__dirname, 'public');
const USERS_FILE = path.join(__dirname, 'users.json');
const MESSAGES_FILE = path.join(__dirname, 'messages.json');
const SHORTS_FILE = path.join(__dirname, 'shorts.json');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads');

// Secret hanya digunakan server; tidak pernah dikirim ke browser.
const TMDB_API_KEY = process.env.TMDB_API_KEY || '82524e2faef91706a2d52d52496130ac';
const TMDB_BASE = process.env.TMDB_BASE || 'https://api.themoviedb.org/3';
const SESSION_TTL = 30 * 24 * 3600 * 1000;   // cookie sesi: 30 hari
const DEVICE_TTL = 180 * 24 * 3600 * 1000;   // token perangkat (localStorage): 180 hari
const SESSION_SECRET = process.env.SESSION_SECRET || 'dxstream-local-session-change-this-secret';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'DensXD';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'DensXD@admin22';

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE) || !fs.readFileSync(USERS_FILE, 'utf8').trim()) fs.writeFileSync(USERS_FILE, '[]');
if (!fs.existsSync(MESSAGES_FILE)) fs.writeFileSync(MESSAGES_FILE, '[]');
if (!fs.existsSync(SHORTS_FILE)) fs.writeFileSync(SHORTS_FILE, '{}');

function readJson(file, fallback = []) { try { return JSON.parse(fs.readFileSync(file, 'utf8') || JSON.stringify(fallback)); } catch { return fallback; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
function id() { return crypto.randomUUID(); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) { return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`; }
function verifyPassword(password, stored) { try { const [salt, key] = stored.split(':'); const candidate = crypto.scryptSync(password, salt, 64).toString('hex'); return crypto.timingSafeEqual(Buffer.from(candidate, 'hex'), Buffer.from(key, 'hex')); } catch { return false; } }
function signSession(payload, ttl = SESSION_TTL) { const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + ttl })).toString('base64url'); const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url'); return `${body}.${sig}`; }
function verifyToken(token) { if (!token || typeof token !== 'string') return null; const [body, sig] = token.split('.'); if (!body || !sig) return null; const expected = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url'); if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null; try { const session = JSON.parse(Buffer.from(body, 'base64url').toString()); return session.exp > Date.now() ? session : null; } catch { return null; } }
function readSession(req) { const token = (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('dx_session='))?.split('=')[1]; return verifyToken(token); }
function setSessionCookie(req, res, user) { res.cookie('dx_session', signSession({ id: user.id }), { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: SESSION_TTL }); }
function deviceToken(user) { return signSession({ id: user.id, kind: 'device' }, DEVICE_TTL); }
function publicUser(user) { return { id: user.id, username: user.username, role: user.role, verified: Boolean(user.verified), createdAt: user.createdAt }; }
function currentUser(req) { const session = readSession(req); return session ? readJson(USERS_FILE).find(u => u.id === session.id) || null : null; }
function requireAuth(req, res, next) { const user = currentUser(req); if (!user) return res.status(401).json({ error: 'Silakan login terlebih dahulu.' }); req.user = user; next(); }
function requireAdmin(req, res, next) { requireAuth(req, res, () => req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Akses admin diperlukan.' })); }
function safeText(value, max = 2000) { return String(value || '').trim().slice(0, max); }

// Seed admin: hapus admin lama jika password tidak cocok, lalu buat ulang dengan password dari env.
function seedAdmin() {
  const users = readJson(USERS_FILE);
  const idx = users.findIndex(u => u.username.toLowerCase() === ADMIN_USERNAME.toLowerCase());
  if (idx >= 0) {
    // Perbarui password admin agar selalu sinkron dengan env (fix login admin).
    users[idx].passwordHash = hashPassword(ADMIN_PASSWORD);
    users[idx].role = 'admin';
    users[idx].verified = true;
    writeJson(USERS_FILE, users);
    console.log(`Admin disinkronkan: ${ADMIN_USERNAME} / ${ADMIN_PASSWORD}`);
  } else {
    const admin = { id: id(), username: ADMIN_USERNAME, passwordHash: hashPassword(ADMIN_PASSWORD), role: 'admin', verified: true, createdAt: new Date().toISOString() };
    users.push(admin);
    writeJson(USERS_FILE, users);
    console.log(`Admin dibuat: ${ADMIN_USERNAME} / ${ADMIN_PASSWORD}`);
  }
}
seedAdmin();

app.use(express.json({ limit: '3mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use('/uploads', express.static(UPLOAD_DIR));
const upload = multer({ storage: multer.diskStorage({ destination: UPLOAD_DIR, filename: (_req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(5).toString('hex')}${path.extname(file.originalname).toLowerCase()}`) }), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (_req, file, cb) => cb(null, /^image\/(jpeg|png|gif|webp)$/.test(file.mimetype)) });

app.get('/api/auth/me', (req, res) => { const user = currentUser(req); res.json({ user: user ? publicUser(user) : null }); });
app.post('/api/auth/register', (req, res) => { const username = safeText(req.body.username, 24).replace(/\s+/g, ''); const password = String(req.body.password || ''); if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) return res.status(400).json({ error: 'Username 3–24 karakter, hanya huruf, angka, titik, garis bawah, atau strip.' }); if (password.length < 8) return res.status(400).json({ error: 'Password minimal 8 karakter.' }); const users = readJson(USERS_FILE); if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username sudah dipakai.' }); const user = { id: id(), username, passwordHash: hashPassword(password), role: 'user', verified: false, createdAt: new Date().toISOString() }; users.push(user); writeJson(USERS_FILE, users); setSessionCookie(req, res, user); res.status(201).json({ user: publicUser(user), deviceToken: deviceToken(user) }); });
app.post('/api/auth/login', (req, res) => { const username = safeText(req.body.username, 48); const password = String(req.body.password || ''); const user = readJson(USERS_FILE).find(u => u.username.toLowerCase() === username.toLowerCase()); if (!user || !verifyPassword(password, user.passwordHash)) return res.status(401).json({ error: 'Username atau password salah.' }); setSessionCookie(req, res, user); res.json({ user: publicUser(user), deviceToken: deviceToken(user) }); });
app.post('/api/auth/resume', (req, res) => {
  // Perangkat yang sudah pernah login mengirim token dari localStorage; kalau valid, sesi cookie dipulihkan.
  const payload = verifyToken(String(req.body.token || ''));
  const user = payload && payload.kind === 'device' ? readJson(USERS_FILE).find(u => u.id === payload.id) : null;
  if (!user) return res.status(401).json({ error: 'Perangkat belum dikenali. Silakan login.' });
  setSessionCookie(req, res, user);
  res.json({ user: publicUser(user), deviceToken: deviceToken(user) });
});
app.get('/api/stats', (_req, res) => { const online = new Set(Array.from(onlineUsers.values()).map(u => u.id)).size; res.json({ users: readJson(USERS_FILE).length, online }); });
app.post('/api/auth/logout', (_req, res) => { res.clearCookie('dx_session'); res.json({ ok: true }); });
app.patch('/api/auth/password', requireAuth, (req, res) => { const oldPassword = String(req.body.oldPassword || ''); const newPassword = String(req.body.newPassword || ''); if (!verifyPassword(oldPassword, req.user.passwordHash)) return res.status(401).json({ error: 'Password lama tidak cocok.' }); if (newPassword.length < 8) return res.status(400).json({ error: 'Password baru minimal 8 karakter.' }); const users = readJson(USERS_FILE); const index = users.findIndex(u => u.id === req.user.id); users[index].passwordHash = hashPassword(newPassword); writeJson(USERS_FILE, users); res.json({ ok: true }); });
app.get('/api/users', requireAdmin, (_req, res) => res.json({ users: readJson(USERS_FILE).map(publicUser) }));

app.get('/api/chat/messages', requireAuth, (_req, res) => res.json({ messages: readJson(MESSAGES_FILE).slice(-100) }));
app.post('/api/chat/messages', requireAuth, upload.single('image'), (req, res) => {
  const text = safeText(req.body.text);
  const replyTo = safeText(req.body.replyTo, 80) || null;
  if (!text && !req.file) return res.status(400).json({ error: 'Pesan atau foto wajib diisi.' });
  const message = { id: id(), text, image: req.file ? `/uploads/${req.file.filename}` : null, replyTo, reactions: {}, user: publicUser(req.user), createdAt: new Date().toISOString() };
  const messages = readJson(MESSAGES_FILE);
  messages.push(message);
  writeJson(MESSAGES_FILE, messages.slice(-500));
  io.emit('chat:new', message);
  res.status(201).json({ message });
});
app.post('/api/chat/messages/:messageId/reactions', requireAuth, (req, res) => {
  const emoji = safeText(req.body.emoji, 8);
  const messages = readJson(MESSAGES_FILE);
  const message = messages.find(m => m.id === req.params.messageId);
  if (!message || !emoji) return res.status(404).json({ error: 'Pesan atau reaksi tidak ditemukan.' });
  message.reactions ||= {};
  message.reactions[emoji] ||= [];
  const index = message.reactions[emoji].indexOf(req.user.id);
  if (index >= 0) message.reactions[emoji].splice(index, 1); else message.reactions[emoji].push(req.user.id);
  writeJson(MESSAGES_FILE, messages);
  io.emit('chat:reaction', { messageId: message.id, reactions: message.reactions });
  res.json({ reactions: message.reactions });
});
app.delete('/api/chat/messages/:messageId', requireAuth, (req, res) => {
  const messages = readJson(MESSAGES_FILE);
  const message = messages.find(m => m.id === req.params.messageId);
  if (!message) return res.status(404).json({ error: 'Pesan tidak ditemukan.' });
  const isOwner = message.user?.id === req.user.id;
  const isAdmin = req.user.role === 'admin';
  if (!isOwner && !isAdmin) return res.status(403).json({ error: 'Tidak dapat menghapus pesan orang lain.' });
  const remaining = messages.filter(m => m.id !== message.id);
  writeJson(MESSAGES_FILE, remaining);
  io.emit('chat:delete', { messageId: message.id });
  res.json({ ok: true });
});

// === GROUP CHAT: track online users ===
const onlineUsers = new Map(); // socketId -> { id, username, role, verified }

function emitOnlineCount() {
  // Deduplicate by user id (one user may open multiple tabs).
  const unique = new Map();
  for (const u of onlineUsers.values()) unique.set(u.id, u);
  const list = Array.from(unique.values());
  io.emit('chat:online', { count: list.length, users: list });
}

io.use((socket, next) => {
  // Auth socket connection via cookie.
  try {
    const session = readSession({ headers: { cookie: socket.handshake.headers.cookie || '' } });
    if (!session) return next(new Error('unauthorized'));
    const user = readJson(USERS_FILE).find(u => u.id === session.id);
    if (!user) return next(new Error('unauthorized'));
    socket.dxUser = publicUser(user);
    next();
  } catch (e) { next(new Error('unauthorized')); }
});

io.on('connection', socket => {
  const user = socket.dxUser;
  if (!user) { socket.disconnect(); return; }

  onlineUsers.set(socket.id, user);
  emitOnlineCount();
  io.emit('chat:presence', { type: 'join', user });

  socket.on('chat:typing', data => {
    socket.broadcast.emit('chat:typing', { username: safeText(data?.username, 24), userId: user.id });
  });

  socket.on('chat:read', () => {
    // simple read receipt — broadcast last read to others (optional).
    socket.broadcast.emit('chat:read', { userId: user.id, at: new Date().toISOString() });
  });

  socket.on('disconnect', () => {
    const was = onlineUsers.get(socket.id);
    onlineUsers.delete(socket.id);
    emitOnlineCount();
    if (was) io.emit('chat:presence', { type: 'leave', user: was });
  });
});

app.get('/api/chat/online', requireAuth, (_req, res) => {
  const unique = new Map();
  for (const u of onlineUsers.values()) unique.set(u.id, u);
  res.json({ count: unique.size, users: Array.from(unique.values()) });
});


// === SHORTS: feed otomatis dari TMDB + like/komentar tersimpan di shorts.json ===
async function tmdbGet(endpoint, params = {}) {
  const url = new URL(`${TMDB_BASE}${endpoint}`);
  url.searchParams.set('api_key', TMDB_API_KEY);
  url.searchParams.set('language', 'id-ID');
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const upstream = await fetch(url);
  if (!upstream.ok) throw new Error(`TMDB ${upstream.status}`);
  return upstream.json();
}
const readShorts = () => readJson(SHORTS_FILE, {});
const entryOf = (db, key) => (db[key] ||= { meta: null, likes: [], comments: [] });
const commentView = (c, uid) => ({ id: c.id, text: c.text, createdAt: c.createdAt, user: c.user, likes: c.likes.length, liked: c.likes.includes(uid) });
function shortMeta(item) { return { key: item.key, id: item.id, type: item.type, title: item.title, year: item.year, rating: item.rating, poster: item.poster, backdrop: item.backdrop }; }
function requireShortKey(req, res, next) { if (!shortsLib.isValidKey(req.params.key)) return res.status(400).json({ error: 'Kunci shorts tidak valid.' }); next(); }

app.get('/api/shorts/feed', requireAuth, async (req, res) => {
  const page = Math.max(1, Math.min(500, parseInt(req.query.page, 10) || 1));
  try {
    const { items } = await shortsLib.buildFeed({ tmdb: tmdbGet, page });
    const db = readShorts();
    res.json({ page, items: items.map(it => { const e = db[it.key]; return { ...it, likes: e ? e.likes.length : 0, liked: Boolean(e && e.likes.includes(req.user.id)), comments: e ? e.comments.length : 0 }; }) });
  } catch (error) { res.status(502).json({ error: 'Feed shorts tidak dapat dimuat dari TMDB.', detail: error.message }); }
});
app.get('/api/shorts/saved', requireAuth, (req, res) => {
  const db = readShorts();
  res.json({ items: Object.values(db).filter(e => e.meta && e.likes.includes(req.user.id)).map(e => e.meta) });
});
app.post('/api/shorts/:key/like', requireAuth, requireShortKey, async (req, res) => {
  const db = readShorts();
  const entry = entryOf(db, req.params.key);
  const index = entry.likes.indexOf(req.user.id);
  if (index >= 0) entry.likes.splice(index, 1);
  else {
    entry.likes.push(req.user.id);
    // Drama otomatis tersimpan (meta diambil server dari TMDB, bukan dari client).
    if (!entry.meta) { const item = await shortsLib.getShort(tmdbGet, req.params.key); if (item) entry.meta = shortMeta(item); }
  }
  writeJson(SHORTS_FILE, db);
  res.json({ liked: index < 0, likes: entry.likes.length, saved: index < 0 });
});
app.get('/api/shorts/:key/comments', requireAuth, requireShortKey, (req, res) => {
  const entry = readShorts()[req.params.key];
  const list = (entry ? entry.comments : []).map(c => commentView(c, req.user.id));
  list.sort((a, b) => b.likes - a.likes || new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ comments: list });
});
app.post('/api/shorts/:key/comments', requireAuth, requireShortKey, (req, res) => {
  const text = safeText(req.body.text, 500);
  if (!text) return res.status(400).json({ error: 'Komentar tidak boleh kosong.' });
  const db = readShorts();
  const entry = entryOf(db, req.params.key);
  const comment = { id: id(), text, user: publicUser(req.user), likes: [], createdAt: new Date().toISOString() };
  entry.comments.push(comment);
  if (entry.comments.length > 400) entry.comments.splice(0, entry.comments.length - 400);
  writeJson(SHORTS_FILE, db);
  res.status(201).json({ comment: commentView(comment, req.user.id), total: entry.comments.length });
});
app.post('/api/shorts/:key/comments/:commentId/like', requireAuth, requireShortKey, (req, res) => {
  const db = readShorts();
  const comment = db[req.params.key]?.comments.find(c => c.id === req.params.commentId);
  if (!comment) return res.status(404).json({ error: 'Komentar tidak ditemukan.' });
  const index = comment.likes.indexOf(req.user.id);
  if (index >= 0) comment.likes.splice(index, 1); else comment.likes.push(req.user.id);
  writeJson(SHORTS_FILE, db);
  res.json({ liked: index < 0, likes: comment.likes.length });
});
app.delete('/api/shorts/:key/comments/:commentId', requireAuth, requireShortKey, (req, res) => {
  const db = readShorts();
  const entry = db[req.params.key];
  const comment = entry?.comments.find(c => c.id === req.params.commentId);
  if (!comment) return res.status(404).json({ error: 'Komentar tidak ditemukan.' });
  if (comment.user?.id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Tidak dapat menghapus komentar orang lain.' });
  entry.comments = entry.comments.filter(c => c.id !== comment.id);
  writeJson(SHORTS_FILE, db);
  res.json({ ok: true, total: entry.comments.length });
});

app.get('/api/tmdb/*', async (req, res) => { try { const url = new URL(`${TMDB_BASE}/${req.params[0]}`); url.searchParams.set('api_key', TMDB_API_KEY); Object.entries(req.query).forEach(([k, v]) => url.searchParams.set(k, v)); if (!url.searchParams.has('language')) url.searchParams.set('language', 'id-ID'); const upstream = await fetch(url); res.status(upstream.status).type('json').send(await upstream.text()); } catch (error) { res.status(502).json({ error: 'TMDB tidak dapat diakses.', detail: error.message }); } });

app.get('/', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'verifikasi.html')));
app.get('/verifikasi.html', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'verifikasi.html')));
app.get('/landing-page.html', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'landing-page.html')));
app.get('/login/daftar.html', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'login', 'daftar.html')));
app.use(express.static(PUBLIC_DIR));
app.get('*', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'verifikasi.html')));
server.listen(PORT, '0.0.0.0', () => console.log(`DXSTREAM server berjalan di http://localhost:${PORT}`));
