/* Scroll reveal: elemen .reveal muncul perlahan saat masuk layar. Pakai DXReveal.scan(root) untuk konten dinamis. */
(function () {
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var io = null;
  function show(el) { el.classList.add('in'); }
  if (!reduce && 'IntersectionObserver' in window) {
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  }
  function scan(root) {
    root = root || document;
    // Anak dari [data-stagger] mendapat jeda bertahap otomatis.
    root.querySelectorAll('[data-stagger]').forEach(function (parent) {
      var step = parseFloat(parent.getAttribute('data-stagger')) || 0.07;
      Array.prototype.forEach.call(parent.children, function (child, i) {
        if (!child.classList.contains('reveal')) child.classList.add('reveal');
        if (!child.style.getPropertyValue('--d')) child.style.setProperty('--d', Math.min(i, 12) * step + 's');
      });
    });
    root.querySelectorAll('.reveal:not(.in)').forEach(function (el) { if (io) io.observe(el); else show(el); });
  }
  window.DXReveal = { scan: scan };
  document.addEventListener('DOMContentLoaded', function () { scan(document); });
})();
