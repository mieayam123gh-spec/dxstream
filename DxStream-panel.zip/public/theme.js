/* DXSTREAM theme: terang (default, ala Sairipedia) / gelap. Dimuat di <head> agar tidak berkedip. */
(function () {
  var KEY = 'dx_theme';
  function stored() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function current() { return stored() || (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); }
  function apply(t) {
    document.documentElement.setAttribute('data-theme', t);
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t === 'dark' ? '#0D0D0C' : '#F4F4F2');
    document.querySelectorAll('[data-theme-toggle] .theme-label').forEach(function (n) { n.textContent = t === 'dark' ? 'Light' : 'Dark'; });
    document.querySelectorAll('[data-theme-toggle] use').forEach(function (u) { u.setAttribute('href', '/icons.svg#' + (t === 'dark' ? 'sun' : 'moon')); });
  }
  apply(current());
  window.DXTheme = {
    toggle: function () { var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; try { localStorage.setItem(KEY, next); } catch (e) {} apply(next); },
    apply: apply
  };
  document.addEventListener('DOMContentLoaded', function () {
    apply(current());
    document.querySelectorAll('[data-theme-toggle]').forEach(function (b) { b.addEventListener('click', window.DXTheme.toggle); });
  });
})();
