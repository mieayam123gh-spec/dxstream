(function () {
  var $ = function (s) { return document.querySelector(s); };

  /* Navbar: bayangan saat scroll + menu mobile + link aktif */
  var nav = $('#nav');
  addEventListener('scroll', function () { nav.classList.toggle('scrolled', scrollY > 10); }, { passive: true });
  var burger = $('#burger'), links = $('#navLinks');
  burger.addEventListener('click', function () { var open = links.classList.toggle('open'); burger.setAttribute('aria-expanded', open); });
  links.addEventListener('click', function (e) { if (e.target.tagName === 'A') { links.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); } });
  var sections = Array.prototype.map.call(links.querySelectorAll('a'), function (a) { return { a: a, el: document.querySelector(a.getAttribute('href')) }; });
  if ('IntersectionObserver' in window) {
    var spy = new IntersectionObserver(function (en) {
      en.forEach(function (e) { if (e.isIntersecting) sections.forEach(function (s) { s.a.classList.toggle('active', s.el === e.target); }); });
    }, { rootMargin: '-40% 0px -55% 0px' });
    sections.forEach(function (s) { if (s.el) spy.observe(s.el); });
  }

  /* Perangkat sudah login? Tombol Masuk/Mulai langsung ke halaman utama. */
  var loginBtn = $('#loginBtn'), loginLabel = $('#loginLabel'), ctaStart = $('#ctaStart'), ctaBottom = $('#ctaBottom');
  function setLoggedIn(user) {
    loginBtn.href = '/index.html'; loginLabel.textContent = 'Buka DXSTREAM';
    [ctaStart, ctaBottom].forEach(function (b) {
      b.href = '/index.html';
      b.firstChild.nodeValue = 'Lanjut sebagai ' + user.username + ' ';
    });
  }
  function setLoggedOut() {
    loginBtn.href = '/login/daftar.html?mode=login'; loginLabel.textContent = 'Masuk';
    [ctaStart, ctaBottom].forEach(function (b) { b.href = '/login/daftar.html'; b.firstChild.nodeValue = 'Mulai Sekarang '; });
  }
  var saved = DXAuth.get();
  if (saved && saved.user) setLoggedIn(saved.user);          // instan dari localStorage
  DXAuth.verify().then(function (u) { if (u) setLoggedIn(u); else setLoggedOut(); }); // lalu dipastikan ke server

  /* Statistik live + count-up */
  function countUp(el, to) {
    var start = performance.now(), dur = 1400;
    (function tick(now) {
      var p = Math.min(1, (now - start) / dur), eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(to * eased).toLocaleString('id-ID');
      if (p < 1) requestAnimationFrame(tick);
    })(start);
  }
  fetch('/api/stats').then(function (r) { return r.json(); }).then(function (s) {
    countUp($('#statOnline'), s.online || 0); countUp($('#statUsers'), s.users || 0);
  }).catch(function () { $('#statOnline').textContent = '0'; $('#statUsers').textContent = '0'; });

  /* Poster dekoratif dari TMDB (gagal = tetap tampil sebagai kartu polos) */
  fetch('/api/tmdb/trending/movie/week').then(function (r) { return r.json(); }).then(function (d) {
    var list = (d.results || []).filter(function (m) { return m.poster_path; });
    if (!list.length) return;
    document.querySelectorAll('[data-poster]').forEach(function (el) {
      var m = list[+el.getAttribute('data-poster') % list.length];
      el.style.backgroundImage = 'url(https://image.tmdb.org/t/p/w342' + m.poster_path + ')';
    });
    document.querySelectorAll('[data-poster-bg]').forEach(function (el) {
      var m = list[+el.getAttribute('data-poster-bg') % list.length];
      el.style.backgroundImage = 'url(https://image.tmdb.org/t/p/w500' + (m.poster_path) + ')';
    });
  }).catch(function () {});

  /* Parallax halus mengikuti kursor (desktop saja) */
  var hv = $('#heroVisual');
  if (hv && matchMedia('(hover:hover) and (min-width: 981px)').matches) {
    var items = hv.querySelectorAll('[data-depth]');
    hv.addEventListener('mousemove', function (e) {
      var r = hv.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      items.forEach(function (it) { var d = +it.getAttribute('data-depth'); it.style.translate = (x * d) + 'px ' + (y * d) + 'px'; });
    });
    hv.addEventListener('mouseleave', function () { items.forEach(function (it) { it.style.translate = '0 0'; }); });
  }
})();
