/* Komentar + like komentar, dipakai bersama oleh Shorts dan halaman detail film.
   Semua tersimpan di server (shorts.json) dengan kunci "movie-123" / "tv-456",
   jadi komentar di klip Shorts dan di halaman film adalah thread yang sama. */
(function () {
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
  function ago(iso) {
    var s = Math.max(1, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 60) return 'baru saja';
    if (s < 3600) return Math.floor(s / 60) + ' mnt lalu';
    if (s < 86400) return Math.floor(s / 3600) + ' jam lalu';
    if (s < 2592000) return Math.floor(s / 86400) + ' hari lalu';
    return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
  }
  async function api(url, opt) {
    var r = await fetch(url, opt);
    var d = await r.json().catch(function () { return {}; });
    if (!r.ok) throw new Error(d.error || 'Terjadi kesalahan.');
    return d;
  }
  var json = function (method, body) { return { method: method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }; };
  var toast = function (m) { if (window.showToast) window.showToast(m); };

  function create(o) {
    var key = null, items = [], busy = false;
    var me = function () { try { return dxUser || {}; } catch (e) { return {}; } };

    function row(c) {
      var mine = c.user && c.user.id === me().id, admin = me().role === 'admin';
      var badges = (c.user && c.user.verified ? '<svg class="ic vf"><use href="/icons.svg#check"/></svg>' : '') + (c.user && c.user.role === 'admin' ? '<em class="admin-tag">ADMIN</em>' : '');
      return '<article class="cmt" data-id="' + c.id + '">' +
        '<span class="avatar">' + esc((c.user && c.user.username || '?')[0].toUpperCase()) + '</span>' +
        '<div class="cmt-body"><div class="cmt-meta"><b>' + esc(c.user && c.user.username) + '</b>' + badges + '<time>' + ago(c.createdAt) + '</time></div>' +
        '<p>' + esc(c.text) + '</p>' +
        (mine || admin ? '<button class="cmt-del" data-act="del" type="button">Hapus</button>' : '') + '</div>' +
        '<button class="cmt-like ' + (c.liked ? 'liked' : '') + '" data-act="like" type="button" aria-label="Suka komentar"><svg class="ic"><use href="/icons.svg#heart"/></svg><small>' + (c.likes || '') + '</small></button></article>';
    }
    function render() {
      if (!items.length) { o.list.innerHTML = '<div class="cmt-empty"><svg class="ic"><use href="/icons.svg#message"/></svg><p>Belum ada komentar. Jadilah yang pertama.</p></div>'; }
      else o.list.innerHTML = items.map(row).join('');
      if (o.onCount) o.onCount(items.length);
    }
    function sort() { items.sort(function (a, b) { return (b.likes - a.likes) || (new Date(b.createdAt) - new Date(a.createdAt)); }); }

    o.list.addEventListener('click', async function (e) {
      var btn = e.target.closest('[data-act]'); if (!btn || !key) return;
      var id = btn.closest('.cmt').dataset.id, c = items.find(function (x) { return x.id === id; }); if (!c) return;
      try {
        if (btn.dataset.act === 'like') {
          c.liked = !c.liked; c.likes += c.liked ? 1 : -1; render();               // optimistis
          var d = await api('/api/shorts/' + key + '/comments/' + id + '/like', json('POST'));
          c.liked = d.liked; c.likes = d.likes; render();
        } else if (btn.dataset.act === 'del') {
          if (!confirm('Hapus komentar ini?')) return;
          await api('/api/shorts/' + key + '/comments/' + id, { method: 'DELETE' });
          items = items.filter(function (x) { return x.id !== id; }); render(); toast('Komentar dihapus.');
        }
      } catch (err) { toast(err.message); if (btn.dataset.act === 'like') load(key); }
    });

    async function submit() {
      var text = o.input.value.trim(); if (!text || busy || !key) return;
      busy = true;
      try {
        var d = await api('/api/shorts/' + key + '/comments', json('POST', { text: text }));
        items.unshift(d.comment); o.input.value = ''; sort(); render();
        o.list.scrollTop = 0;
      } catch (err) { toast(err.message); } finally { busy = false; }
    }
    if (o.form) o.form.addEventListener('submit', function (e) { e.preventDefault(); submit(); });
    if (o.submit) o.submit.addEventListener('click', function (e) { e.preventDefault(); submit(); });
    o.input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !o.form) { e.preventDefault(); submit(); } });

    async function load(k) {
      key = k; items = [];
      o.list.innerHTML = '<div class="cmt-empty"><p>Memuat komentar…</p></div>';
      try { var d = await api('/api/shorts/' + k + '/comments'); if (key !== k) return; items = d.comments; render(); }
      catch (err) { o.list.innerHTML = '<div class="cmt-empty"><p>' + esc(err.message) + '</p></div>'; }
    }
    return { load: load, get key() { return key; }, get total() { return items.length; } };
  }
  window.DXComments = { create: create };
})();
