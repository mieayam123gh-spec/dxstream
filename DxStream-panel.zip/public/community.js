/* DXSTREAM ACCOUNT + GLOBAL CHAT (NETFLIX-STYLE GROUP CHAT) */
let dxUser = null;
let replyTarget = null;
let dxSocket = null;
let onlineCount = 0;
let onlineUsers = [];
const chatEmojiSet = ['❤️', '🔥', '😂', '👏', '😍', '😮'];

async function jsonRequest(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Terjadi kesalahan.');
  return data;
}

async function bootAuthAndCommunity() {
  try {
    // Cookie sesi ATAU token perangkat di localStorage (login tersimpan di perangkat ini).
    const user = await DXAuth.verify();
    if (!user) { location.replace('/login/daftar.html?mode=login'); return false; }
    const data = { user: (await jsonRequest('/api/auth/me').catch(() => ({ user }))).user || user };
    dxUser = data.user;
    renderProfile();
    bindCommunityControls();
    // Di Vercel (rewrite HTTP) WebSocket tidak bisa diproxy, jadi pakai long-polling saja.
    // Diakses langsung ke panel (localhost / :2255) tetap WebSocket. Bisa dipaksa lewat window.DX_SOCKET_POLLING.
    const direct = location.port === '2255' || /^(localhost|127\.|192\.168\.)/.test(location.hostname);
    const pollingOnly = typeof window.DX_SOCKET_POLLING === 'boolean' ? window.DX_SOCKET_POLLING : !direct;
    dxSocket = window.io ? io(pollingOnly ? { transports: ['polling'], upgrade: false } : {}) : null;
    if (dxSocket) {
      dxSocket.on('connect', () => {
        // Refresh online list once connected
        fetch('/api/chat/online').then(r => r.json()).then(data => {
          onlineCount = data.count;
          onlineUsers = data.users;
          renderOnlineCount();
        }).catch(() => {});
      });
      dxSocket.on('chat:new', message => appendChatMessage(message));
      dxSocket.on('chat:reaction', data => updateMessageReactions(data.messageId, data.reactions));
      dxSocket.on('chat:delete', data => removeChatMessage(data.messageId));
      dxSocket.on('chat:online', data => {
        onlineCount = data.count;
        onlineUsers = data.users;
        renderOnlineCount();
      });
      dxSocket.on('chat:presence', data => {
        if (data.type === 'join') showToast(`${data.user.username} bergabung ke chat`);
        else if (data.type === 'leave') showToast(`${data.user.username} meninggalkan chat`);
      });
      dxSocket.on('chat:typing', data => {
        const el = document.getElementById('chatTyping');
        if (el && data.username) {
          el.textContent = `${data.username} sedang mengetik…`;
          el.classList.add('visible');
          clearTimeout(window.__dxTypingTimer);
          window.__dxTypingTimer = setTimeout(() => {
            el.textContent = '';
            el.classList.remove('visible');
          }, 2200);
        }
      });
    }
    return true;
  } catch (error) { console.error(error); location.replace('/login/daftar.html?mode=login'); return false; }
}

function renderOnlineCount() {
  const el = document.getElementById('chatOnlineCount');
  if (el) el.textContent = onlineCount > 0 ? `${onlineCount} online` : 'online';
  const list = document.getElementById('chatOnlineList');
  if (list) {
    const top = onlineUsers.slice(0, 12);
    list.innerHTML = top.map(u => `<span class="online-chip" title="${escapeHtml(u.username)}"><i class="dot"></i>${escapeHtml(u.username)}</span>`).join('');
  }
}

function renderProfile() {
  const name = dxUser.username || 'User';
  const username = document.getElementById('profileUsername');
  if (username) username.textContent = name;
  const avatar = document.getElementById('profileAvatar');
  if (avatar) avatar.textContent = name[0].toUpperCase();
  const role = document.getElementById('profileRole');
  if (role) role.textContent = dxUser.role === 'admin' ? 'Administrator DXSTREAM' : 'Member DXSTREAM';
  const badge = document.getElementById('profileBadge');
  if (badge) badge.classList.toggle('hidden', !dxUser.verified);
  const panel = document.getElementById('adminPanel');
  if (panel && dxUser.role === 'admin') { panel.classList.remove('hidden'); loadUsers(); }
  // Update header avatar (Netflix-style top-right)
  const headerAvatar = document.getElementById('headerAvatar');
  if (headerAvatar) headerAvatar.textContent = (name[0] || 'D').toUpperCase();
}

function bindCommunityControls() {
  document.getElementById('logoutBtn')?.addEventListener('click', async () => { await jsonRequest('/api/auth/logout', { method: 'POST' }).catch(() => {}); DXAuth.clear(); location.replace('/login/daftar.html?mode=login'); });
  document.getElementById('changePasswordBtn')?.addEventListener('click', async () => { const oldPassword = prompt('Masukkan password lama:'); if (!oldPassword) return; const newPassword = prompt('Masukkan password baru (minimal 8 karakter):'); if (!newPassword) return; try { await jsonRequest('/api/auth/password', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ oldPassword, newPassword }) }); showToast('Password berhasil diubah.'); } catch (e) { showToast(e.message); } });
  document.getElementById('chatForm')?.addEventListener('submit', sendChatMessage);
  document.getElementById('emojiButton')?.addEventListener('click', () => { const text = document.getElementById('chatText'); text.value += ` ${chatEmojiSet[Math.floor(Math.random() * chatEmojiSet.length)]}`; text.focus(); });
  document.getElementById('chatText')?.addEventListener('input', () => {
    // Throttle typing event (max once per 1.2s)
    const now = Date.now();
    if (!window.__dxLastTyping || now - window.__dxLastTyping > 1200) {
      window.__dxLastTyping = now;
      dxSocket?.emit('chat:typing', { username: dxUser.username });
    }
  });
}

async function loadUsers() {
  try {
    const data = await jsonRequest('/api/users');
    const list = document.getElementById('userList');
    if (!list) return;
    list.innerHTML = data.users.map(user => `<div class="user-row"><span class="mini-avatar">${escapeHtml(user.username[0].toUpperCase())}</span><strong>${escapeHtml(user.username)}</strong>${user.verified ? '<span class="blue-check">✓</span>' : ''}<small>${user.role}</small></div>`).join('');
  } catch (e) { console.warn(e); }
}

async function loadChatMessages() {
  try {
    const data = await jsonRequest('/api/chat/messages');
    const box = document.getElementById('chatMessages');
    if (!box) return;
    box.innerHTML = '';
    data.messages.forEach(appendChatMessage);
    box.scrollTop = box.scrollHeight;
    // Also refresh online list when entering chat
    fetch('/api/chat/online').then(r => r.json()).then(d => {
      onlineCount = d.count; onlineUsers = d.users; renderOnlineCount();
    }).catch(() => {});
  } catch (e) { showToast(e.message); }
}

function appendChatMessage(message) {
  const box = document.getElementById('chatMessages');
  if (!box || document.querySelector(`[data-message-id="${message.id}"]`)) return;
  const mine = message.user?.id === dxUser?.id;
  const isAdmin = dxUser?.role === 'admin';
  const reply = message.replyTo ? `<div class="quoted-message">↩ Membalas pesan</div>` : '';
  const image = message.image ? `<img class="chat-image" src="${message.image}" alt="Foto kiriman" loading="lazy">` : '';
  const reactions = Object.entries(message.reactions || {}).filter(([, users]) => users.length).map(([emoji, users]) => `<button class="reaction-pill" data-message-id="${message.id}" data-emoji="${emoji}">${emoji} ${users.length}</button>`).join('');
  const canDelete = mine || isAdmin;
  const el = document.createElement('article');
  el.className = `chat-message ${mine ? 'mine' : ''}`;
  el.dataset.messageId = message.id;
  el.innerHTML = `<div class="chat-avatar">${escapeHtml((message.user?.username || '?')[0].toUpperCase())}</div><div class="chat-bubble"><div class="chat-meta"><strong>${escapeHtml(message.user?.username || 'User')}${message.user?.verified ? '<span class="blue-check">✓</span>' : ''}${message.user?.role === 'admin' ? '<span class="admin-tag">ADMIN</span>' : ''}</strong><time>${new Date(message.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</time></div>${reply}${image}<p>${escapeHtml(message.text || '')}</p><div class="message-actions"><button class="reply-btn" data-message-id="${message.id}">↩ Balas</button>${reactions}<button class="react-btn" data-message-id="${message.id}">＋ Reaksi</button>${canDelete ? `<button class="delete-btn" data-message-id="${message.id}">Hapus</button>` : ''}</div></div>`;
  el.querySelector('.reply-btn').onclick = () => {
    replyTarget = message;
    const preview = document.getElementById('replyPreview');
    preview.classList.remove('hidden');
    preview.innerHTML = `Membalas ${escapeHtml(message.user.username)} <button type="button" id="cancelReply">×</button>`;
    document.getElementById('cancelReply').onclick = () => { replyTarget = null; preview.classList.add('hidden'); };
    document.getElementById('chatText').focus();
  };
  el.querySelector('.react-btn').onclick = () => {
    const pick = prompt('Pilih emoji: ' + chatEmojiSet.join(' '), chatEmojiSet[0]);
    if (pick) reactToMessage(message.id, pick.trim());
  };
  el.querySelectorAll('.reaction-pill').forEach(btn => btn.onclick = () => reactToMessage(btn.dataset.messageId, btn.dataset.emoji));
  const delBtn = el.querySelector('.delete-btn');
  if (delBtn) delBtn.onclick = () => {
    if (!confirm('Hapus pesan ini?')) return;
    deleteChatMessage(message.id);
  };
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}

function removeChatMessage(messageId) {
  const el = document.querySelector(`[data-message-id="${messageId}"]`);
  if (el) el.remove();
}

function updateMessageReactions(messageId, reactions) {
  const el = document.querySelector(`[data-message-id="${messageId}"]`);
  if (!el) return;
  el.querySelectorAll('.reaction-pill').forEach(node => node.remove());
  const actions = el.querySelector('.message-actions');
  Object.entries(reactions || {}).filter(([, users]) => users.length).forEach(([emoji, users]) => {
    const button = document.createElement('button');
    button.className = 'reaction-pill';
    button.dataset.messageId = messageId;
    button.dataset.emoji = emoji;
    button.textContent = `${emoji} ${users.length}`;
    button.onclick = () => reactToMessage(messageId, emoji);
    actions.insertBefore(button, actions.querySelector('.react-btn'));
  });
}

async function reactToMessage(messageId, emoji) {
  try {
    const data = await jsonRequest(`/api/chat/messages/${messageId}/reactions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ emoji }) });
    updateMessageReactions(messageId, data.reactions);
  } catch (e) { showToast(e.message); }
}

async function deleteChatMessage(messageId) {
  try {
    await jsonRequest(`/api/chat/messages/${messageId}`, { method: 'DELETE' });
    removeChatMessage(messageId);
    showToast('Pesan dihapus.');
  } catch (e) { showToast(e.message); }
}

async function sendChatMessage(event) {
  event.preventDefault();
  const text = document.getElementById('chatText');
  const image = document.getElementById('chatImage');
  if (!text.value.trim() && !image.files[0]) return;
  const form = new FormData();
  form.append('text', text.value.trim());
  if (image.files[0]) form.append('image', image.files[0]);
  if (replyTarget) form.append('replyTo', replyTarget.id);
  try {
    const data = await jsonRequest('/api/chat/messages', { method: 'POST', body: form });
    // Append immediately for the sender (socket broadcast also fires, but dedupe via data-message-id).
    appendChatMessage(data.message);
    text.value = '';
    image.value = '';
    replyTarget = null;
    document.getElementById('replyPreview')?.classList.add('hidden');
  } catch (e) { showToast(e.message); }
}
